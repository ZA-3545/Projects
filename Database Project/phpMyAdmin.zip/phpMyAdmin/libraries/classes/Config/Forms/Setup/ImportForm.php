<?php
/**
 * User preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Setup;

class ImportForm extends \PhpMyAdmin\Config\Forms\User\ImportForm
{
}
