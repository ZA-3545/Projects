<?php
/* 
 * phpMyAdmin configuration file 
 */

// Secret passphrase for cookie encryption
$cfg['blowfish_secret'] = 'my_secure_random_string_123'; // Use a long, random string here

/* Servers configuration */
$i = 0;
$i++;

/* Server: localhost [1] */
$cfg['Servers'][$i]['auth_type'] = 'cookie';  // <<--- Use 'cookie' for login screen
$cfg['Servers'][$i]['host'] = '127.0.0.1';
$cfg['Servers'][$i]['connect_type'] = 'tcp';
$cfg['Servers'][$i]['compress'] = false;
$cfg['Servers'][$i]['AllowNoPassword'] = true;

// Optional: Uncomment if needed
// $cfg['Servers'][$i]['user'] = 'root';
// $cfg['Servers'][$i]['password'] = '';

/* Directories for saving/loading files from server */
$cfg['UploadDir'] = '';
$cfg['SaveDir'] = '';

?>